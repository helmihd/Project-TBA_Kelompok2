# Project-TBA_Kelompok2

Program turing machine untuk operasi:
   * Penjumlahan --> bilangan bulat positif dan negatif
   * Pengurangan --> bilangan bulat positif dan negatif
   * Perkalian --> bilangan bulat positif dan negatif
   * Pembagian --> bilangan bulat positif dan negatif, dengan pembulatan ke bawah
   * Faktorial (!) --> bilangan bulat positif
   * Pangkat (x^y)--> bilangan bulat positif
   * Akar kuadrat --> bilangan bulat positif, dengan pembulatan kebawah
   * Logaritma biner --> input dan output merupakan bilangan bulat positif

# Template GUI

Template GUI dari https://github.com/rdbende/Azure-ttk-theme

# Cara penggunaan program

1. Pastikan python sudah terinstall pada computer
2. Pastikan sudah menambahkan PATH dari folder python ke dalam pc
3. Download project dalam bentuk zip kemudian extract atau clone repository
4. Jalankan main.py
